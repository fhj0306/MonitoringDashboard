#!/bin/bash
refresh_rate=5 # 기본 새로고침 비율을 5초로 설정
selected_option="m"

# press key result
selected_option_result=""

# set 환경 변수
export PATH=$PATH:/usr/lpp/mmfs/bin

tput civis
clear

print_centered() {
    local line=$1
    local text_length=$(echo -ne "$line" | sed 's/\x1b\[[0-9;]*m//g' | wc -m | tr -d ' ')
    local padding=$((($width - $text_length) / 2))
    printf "%${padding}s" ""
    echo -e "$line"
}

print_with_padding() {
    local text=$1
    local color=$2
    width=$(tput cols)
    if [[ -n $color ]]; then
        text_length=$(echo -ne "${color}${text}\033[0m" | wc -m | tr -d ' ')
        visible_length=${#text}
    else
        visible_length=${#text}
    fi
    remaining_width=$((width - visible_length))
    if [[ -n $color ]]; then
        echo -ne "${color}${text}\033[0m"
    else
        echo -n "$text"
    fi
    printf '%*s' $remaining_width | tr ' ' "_"
    echo ""
}

print_menu() {
    local width=$(tput cols)
    
    local fs_color="\033[34m" # default color : BLUE
    local cl_color="\033[34m"
    local lg_color="\033[34m"
    local io_color="\033[34m"
    local hc_color="\033[34m"
    local sc_color="\033[34m"
    local mr_color="\033[34m"
    local qt_color="\033[34m"


    case $selected_option in
        f) fs_color="\033[1;35;47m";; #selected option color
        c) cl_color="\033[1;35;47m";;
        l) lg_color="\033[1;35;47m";;
        d) io_color="\033[1;35;47m";;
        h) hc_color="\033[1;35;47m";;
        s) sc_color="\033[1;35;47m";;
        m) mr_color="\033[1;35;47m";;
        q) qt_color="\033[1;35;47m";;
    esac
    local option_lines=(
        "   __OPTIONS(press key)________________________________"
        "  |${fs_color}f\033[0m:filesystem state   ${cl_color}c\033[0m:cluster state   ${lg_color}l\033[0m:system logs |"
        "  |${io_color}d\033[0m:disk I/O           ${hc_color}h\033[0m:health check    ${sc_color}s\033[0m:system check|"
        "  |${mr_color}m\033[0m:Main(System resource)                ${qt_color}q\033[0m:Quit        |"
        "  |_____________________________________________________|"
    )
    for line in "${option_lines[@]}"; do
        print_centered "$line"
    done
}



# 선택옵션의 실행결과 출력
print_selected_option_result() {
    if [[ ! -z "$selected_option_result" ]]; then
        echo -e "$selected_option_result"
        echo ""
        return 0
    else
        return 1
    fi
}

while true; do
    tput cup 0 0
    tput ed
    width=$(tput cols)

    title="\033[43;1;31mSERVER MONITORING DASHBOARD\033[0m"
    print_centered "$title"

    print_menu # 메뉴 출력

    
    # Display SYSTEM RESOURCE
    if ! print_selected_option_result; then
        print_with_padding "SYSTEM RESOURCE" "\033[47;30m"
        echo -e "◼ \e[1;33mCPU\e[0m"
        mpstat
        echo ""
        echo -e "◼ \e[1;33mProcess(CPU USING)\e[0m"
	ps -eo user,pid,pcpu,cmd --sort -pcpu | head -n6
        echo ""

     	echo -e "◼ \e[1;33mUser CPU Usage\e[0m"
	ps -eo user,%cpu --sort=-%cpu | awk 'NR>1 {arr[$1]+=$2} END {for (i in arr) {print i, arr[i]"%"}}' | sort -k2 -nr | head -n5
	echo ""

        echo -e "◼ \e[1;32mMEMORY\e[0m"
        free
        free | awk '/Mem/ {printf("-Memory Usage: %.2f%%\n", $3/$2 * 100)}'
        free | awk '/Swap/ {printf("-Swap Usage  : %.2f%%\n", $3/$2 * 100)}'
        echo ""
        echo -e "◼ \e[1;32mProcess(MEMORY USING)\e[0m"
	ps -eo user,pid,pmem,cmd --sort -pmem | head -n6

	echo ""
	echo -e "◼ \e[1;32mUser Memory Usage\e[0m"
	ps -eo user,%mem --sort=-%mem | awk 'NR>1 {arr[$1]+=$2} END {for (i in arr) {print i, arr[i]"%"}}' | sort -k2 -nr | head -n5

        echo ""
        echo -e "◼ \e[1;36mDISK usage\e[0m"
        df -t ext4 -t xfs -h
        echo ""
        echo -e "◼ \e[1;34mNetwork Traffic\e[0m"
        cat /proc/net/dev
    fi

    # Refresh every 5 seconds
    read -t $refresh_rate -n 1 -s input
    case $input in
        f) selected_option_result=$(./FSstate.sh 2>&1) # 명령어의 STDERR를 STDOUT으로 리다이렉트
           selected_option="$input" 
    	   exit_status=$? # 마지막으로 실행된 명령어의 종료 상태를 캡처
	   if [[ exit_status -ne 0 ]]; then
	     # Error
            case "$selected_option_result" in
                *"not available to run the command"*)
                    selected_option_result="Some Node is not available to run the command.\nPlease check the node status or GPFS status on the cluster."
                ;;
            	*"command cannot be executed"*)
                selected_option_result="Command cannot be executed. Check if the cluster nodes are reachable or if GPFS is down."
                ;;
            	*"No such file or directory"*)
               	selected_option_result="The required filesystem is not found or not mounted. Please verify the filesystem configuration."
           	;;
            	*)
               	 # 일반적인 오류 메시지
               	 selected_option_result="An unexpected error occurred: $selected_option_result"
           	     ;;
            	esac
        fi
        ;;
        m) selected_option_result=""
           selected_option="$input" ;;           
        c) selected_option_result=$(script -q -c "./ClusterState.sh" /dev/null)
           selected_option="$input"  ;;
        l) selected_option_result=$(script -q -c "./Systemlog.sh" /dev/null) 
           selected_option="$input" ;;
        d) selected_option_result=$(script -q -c "./DiskIO.sh" /dev/null) 
           selected_option="$input" ;;
        h) selected_option_result=$(script -q -c "./HealthCheck.sh" /dev/null) 
           selected_option="$input" ;;
        s) selected_option_result=$(script -q -c "./SystemCheck.sh" /dev/null) 
           selected_option="$input" ;;
        q) 
	    clear
      	    tput cnorm
            exit 0
            ;;
        *)
    esac
done

tput cnorm
