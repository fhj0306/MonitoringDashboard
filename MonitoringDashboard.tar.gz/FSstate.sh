#!/bin/bash

print_with_padding() {
    local text=$1
    local color=$2
    local width=$(tput cols)
    if [[ -n $color ]]; then
        local text_length=$(echo -ne "${color}${text}\033[0m" | wc -m | tr -d ' ')
        local visible_length=${#text}
    else
        local visible_length=${#text}
    fi
    local remaining_width=$((width - visible_length))
    if [[ -n $color ]]; then
        echo -ne "${color}${text}\033[0m"
    else
        echo -n "$text"
    fi
    printf '%*s' $remaining_width | tr ' ' "_"
    echo ""
}

print_with_padding "FILESYSTEM STATE" "\033[47;30m"



# 파일 시스템 이름 추출
mapfile -t gpfs_fs_names < <(mmlsfs all | grep "^File system attributes for" | awk '{name=$5; gsub(/:$/, "", name); print name}' | rev | cut -d'/' -f1 | rev)

# 각 파일 시스템에 대한 'mmdf' 명령어 실행
for fs_name in "${gpfs_fs_names[@]}"; do
    echo "GPFS Filesystem name: $fs_name"
    echo "$fs_name Disk usage:"
    mmdf $fs_name
    echo ""
done

echo "GPFS Cluster Node Status"
mmgetstate -a

echo ""

mmlscluster

