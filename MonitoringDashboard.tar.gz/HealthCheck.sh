#!/bin/bash

print_with_padding() {
    local text=$1
    local color=$2
    width=$(tput cols)
    if [[ -n $color ]]; then
        text_length=$(echo -ne "${color}${text}\033[0m" | wc -m | tr -d ' ')
        visible_length=${#text}
    else
        visible_length=${#text}
    fi
    remaining_width=$((width - visible_length))
    if [[ -n $color ]]; then
        echo -ne "${color}${text}\033[0m"
    else
        echo -n "$text"
    fi
    printf '%*s' $remaining_width | tr ' ' "_"
    echo ""
}

print_with_padding "HEALTH CHECK" "\033[47;30m"

echo -en "◼ \e[1;36mNode Health Check\e[0m"
# mmlsnode 명령어 실행 결과에서 노드 이름 추출
nodes=$(mmlsnode | awk '/Node list/ {getline; getline; for (i=2; i<=NF; i++) printf $i " "; print ""}')
# mmlsnode 실행결과에서 Node list 매치, getline으로 줄 건너뛰기 -> 노드가 나열된 줄로 이동
# nodeset이름을 건너뛰고 2번쨰 인자부터 마지막 인자까지 출력(printf $i " " 를 통해 공백으로 구분)

# 공백으로 구분된 노드 순차적으로 명령어 출력
for nodename in $nodes; do
    mmhealth node show -N $nodename --color
    echo "" 
done

echo ""
echo -en "◼ \e[1;34mCluster Health Check\e[0m"
mmhealth cluster show
