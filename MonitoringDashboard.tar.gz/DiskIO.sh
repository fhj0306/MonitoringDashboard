#!/bin/bash


print_with_padding() {
    local text=$1
    local color=$2
    width=$(tput cols)
    if [[ -n $color ]]; then
        text_length=$(echo -ne "${color}${text}\033[0m" | wc -m | tr -d ' ')
        visible_length=${#text}
    else
        visible_length=${#text}
    fi
    remaining_width=$((width - visible_length))
    if [[ -n $color ]]; then
        echo -ne "${color}${text}\033[0m"
    else
        echo -n "$text"
    fi
    printf '%*s' $remaining_width | tr ' ' "_"
    echo ""
}

print_with_padding "DISK STATE" "\033[47;30m"

echo -e "◼ \e[1;36mDISK usage\e[0m"
        df -t ext4 -t xfs -h

echo ""
echo -e "◼ \e[1;33mDISK I/O\e[0m"
iostat -h -d

echo -e "◼ \e[1;33mBlock Devices List\e[0m"
lsblk
