#!/bin/bash

print_with_padding() {
    local text=$1
    local color=$2
    local width=$(tput cols)
    if [[ -n $color ]]; then
        local text_length=$(echo -ne "${color}${text}\033[0m" | wc -m | tr -d ' ')
        local visible_length=${#text}
    else
        local visible_length=${#text}
    fi
    local remaining_width=$((width - visible_length))
    if [[ -n $color ]]; then
        echo -ne "${color}${text}\033[0m"
    else
        echo -n "$text"
    fi
    printf '%*s' $remaining_width | tr ' ' "_"
    echo ""
}

# os
print_with_padding "SYSTEM INFORMATIONS" "\033[47;30m"
echo -e "◼ \e[1;32mLinux Distribution and Version:\e[0m"
if command -v lsb_release &> /dev/null; then
    lsb_release -a
else
    cat /etc/*release
fi
echo ""

# Network Interface Info
echo -e "◼ \e[1;34mNetwork Interface\e[0m"
ip addr
echo -e "◼ \e[1;34mNetwork Interfaces state\e[0m"
ip -brief link
echo ""

# HW information
echo -e "◼ \e[1;36mCPU Information\e[0m"
lscpu | grep "Model name\|CPU(s):"
echo ""

echo -e "◼ \e[1;36mMemory Information\e[0m"
grep MemTotal /proc/meminfo
echo ""

echo -e "◼ \e[1;36mDisk Information\e[0m"
lsblk | grep disk




